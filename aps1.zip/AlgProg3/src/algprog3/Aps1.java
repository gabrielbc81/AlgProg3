/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algprog3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Aps1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				try {
					Scanner sc = new Scanner(new FileReader("Caminho do arq"));
					int col = sc.nextInt();
					int lin = sc.nextInt();
					int[][] mat = new int[lin][col];
					int index = 0;
					while (sc.hasNext()){
						mat[index] = stringToArray(sc.next());
						index++;
					}

				
					printMatriz(mat);
					int[][] copia1 = new int[lin][col];
					int[][] copia2 = new int[lin][col];

					copiaDados(mat, copia1);
					copiaDados(mat, copia2);
					
					printMatriz(copia1);
					System.out.println("");
					System.out.println("");
					printMatriz(copia2);
				
				} catch (FileNotFoundException ex) {
		            System.out.println(ex.getMessage());
		            System.exit(0);
		        }	
			}

			static int[] stringToArray(String str){
				int[] array = new int[str.length()];
					for (int i=0; i < str.length(); i++){
						array[i] = Integer.parseInt(str.substring(i, i+1));
					}
				return array;
			}
			
			static void printMatriz(int[][] matriz){
				for(int index = 0; index < matriz.length; index ++){
					System.out.print("|");
					for (int i = 0; i< matriz[index].length; i++){
						System.out.print(matriz[index][i] + "|");
					}
					System.out.println("");
				}
			}
			
			static void copiaDados(int[][] origem, int[][] destino){
				for(int index = 0; index < origem.length; index ++){
					for (int i = 0; i< origem[index].length; i++){
						destino[index][i] = origem[index][i];
					}
				}

	}

}
